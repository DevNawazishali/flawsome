import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import "./Header.css"
import logo from "../Assets/logo.png"
export default function Header() {
    return (
        <div>
            <Navbar collapseOnSelect expand="lg" className="mainNavBar">
                <Container>
                    <Navbar.Brand href="#home" className='navlogo'>
                        <img src={logo} alt="" />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="m-auto">
                            <Nav.Link href="#features">Home</Nav.Link>
                            <Nav.Link href="#pricing">About Us</Nav.Link>
                            <Nav.Link href="#pricing">Services</Nav.Link>
                            <Nav.Link href="#pricing">Psychologists</Nav.Link>
                            <Nav.Link href="#pricing">Blog </Nav.Link>
                            <Nav.Link href="#pricing">The story garden </Nav.Link>
                            <Nav.Link href="#pricing">	Flawsome voices </Nav.Link>
                            <Nav.Link href="#pricing">Resource  </Nav.Link>
                            <Nav.Link href="#pricing">Testimonials  </Nav.Link>
                            {/* <Nav.Link href="#pricing">Faq</Nav.Link> */}

                        </Nav>
                        <Nav>
                            <button className=' appointment'> Book a Session </button>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    )
}
