import React from 'react'

export default function Blog() {
  return (
    <div className='Blog'>
    <div className="container">
    <hr style={{ color: "#7e00cd", height: "3px" }} />

        <h1 className='text-center headclr fw-bold pop'>Blogs & Insights – FlawsomePsych</h1>
        <div className="row my-4">
        <div className="col-md-4">
        <div className="blogs teambox h-auto">
            <h6 className='text-center fw-bold '>Latest Articles</h6>
            <p className='paraclr pop text-center '>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum repellendus officia optio, odio, quos dolore nulla illo itaque nihil numquam repellat nobis ab perspiciatis error deleniti adipisci ipsam omnis non?</p>
            <div className='d-flex justify-content-center'>

            <button className='appointment'>Read More </button>
            </div>

            </div>
        </div>
        <div className="col-md-4 mt-3 mt-md-0">
        <div className="blogs teambox h-auto">
            <h6 className='text-center fw-bold '>Latest Articles</h6>
            <p className='paraclr pop text-center '>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum repellendus officia optio, odio, quos dolore nulla illo itaque nihil numquam repellat nobis ab perspiciatis error deleniti adipisci ipsam omnis non?</p>
            <div className='d-flex justify-content-center'>

            <button className='appointment'>Read More </button>
            </div>

            </div>
        </div>
        <div className="col-md-4 mt-3 mt-md-0">
        <div className="blogs teambox h-auto">
            <h6 className='text-center fw-bold '>Latest Articles</h6>
            <p className='paraclr pop text-center '>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum repellendus officia optio, odio, quos dolore nulla illo itaque nihil numquam repellat nobis ab perspiciatis error deleniti adipisci ipsam omnis non?</p>
            <div className='d-flex justify-content-center'>

            <button className='appointment'>Read More </button>
            </div>

            </div>
        </div>
           
        </div>
    </div>
      
    </div>
  )
}
