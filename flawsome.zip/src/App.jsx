import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Header from './Components/Header/Header';
import LandingPage from './Components/LandingPage/LandingPage';
import AboutUs from './Components/AboutUs/AboutUs';
import WhyUs from './Components/WhyUs/WhyUs';
import Team from './Components/Team/Team';
import Appoinment from './Components/Appoinment/Appoinment';
import Footer from './Components/Footer/Footer';
import Founder from './Components/Founder/Founder';
import Supervision from './Components/Supervision/Supervision';
import Blog from './Components/Blog/Blog';
import Story from './Components/Story/Story';
import FlawVoices from './Components/FlawVoices/FlawVoices';
import Resources from './Components/Resources/Resources';
import Testimonials from './Components/Testimonials/Testimonials';
import JoinUs from './Components/JoinUs/JoinUs';

function App() {


  return (
    <>
    <Header/>
    <LandingPage/>
    <Founder/>
    <AboutUs/>
    <WhyUs/>
    <Supervision/>
    <Team/>
    <Blog/>
    <Story/>
    <FlawVoices/>
    <Resources/>
    <Testimonials/>
    <Appoinment/>
    <JoinUs/>
    <Footer/> 
    </>
  )
}

export default App
